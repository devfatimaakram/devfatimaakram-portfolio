const assert=require('node:assert/strict');
const B=require('../js/booking.js');
let n=0;function test(label,fn){fn();n++;console.log('PASS '+label);}
const now=new Date('2026-10-29T07:10:00Z'); // Thursday 12:10 PKT
 test('Pakistan time is independent of host timezone',()=>assert.deepEqual(B.pakistanNow(now),{date:'2026-10-29',minutes:730}));
 test('Past dates blocked',()=>assert.deepEqual(B.availableTimes('2026-10-28',now),[]));
 test('Sunday blocked',()=>assert.deepEqual(B.availableTimes('2026-11-01',now),[]));
 test('Malformed and impossible dates blocked',()=>{assert.equal(B.validDate('2026-02-30'),false);assert.deepEqual(B.availableTimes('bad',now),[]);});
 test('Same-day expired slots removed',()=>assert.equal(B.availableTimes('2026-10-29',now)[0],'12:30'));
 test('Future weekday has 12 half-hour slots',()=>assert.deepEqual(B.availableTimes('2026-10-30',now),['10:00','10:30','11:00','11:30','12:00','12:30','13:00','13:30','14:00','14:30','15:00','15:30']));
 test('Exact current slot blocked',()=>assert.equal(B.availableTimes('2026-10-29',new Date('2026-10-29T05:00:00Z'))[0],'10:30'));
 test('After closing time no same-day slots',()=>assert.deepEqual(B.availableTimes('2026-10-29',new Date('2026-10-29T10:30:00Z')),[]));
 test('PKT day rollover',()=>assert.equal(B.pakistanNow(new Date('2026-10-29T19:01:00Z')).date,'2026-10-30'));
 test('Sunday provides accessible reason',()=>assert.match(B.dateError('2026-11-01',now),/Sunday/));
 test('Message contains all fields and encodes safely',()=>{const v={name:'Ali & سارہ',email:'ali@example.test',phone:'+92 300',project:'E-commerce',package:'Custom',budget:'PKR 90,000',date:'2026-10-30',time:'15:30',meeting:'Office visit',details:'A & B? #details\nSecond line'};const m=B.message(v);for(const str of ['Ali & سارہ','ali@example.test','+92 300','E-commerce','Custom','PKR 90,000','2026-10-30','3:30 PM','Asia/Karachi (UTC+5)','Office visit',v.details,'not a confirmed booking'])assert.ok(m.includes(str));const url=new URL('https://wa.me/923083602029?text='+encodeURIComponent(m));assert.equal(url.searchParams.get('text'),m);assert.equal(url.pathname,'/923083602029');});
 console.log(`${n} booking tests passed`);
