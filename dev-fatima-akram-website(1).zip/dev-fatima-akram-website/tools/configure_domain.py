#!/usr/bin/env python3
"""Set approved HTTPS origin and switch SEO from review to launch mode. No build dependency."""
import argparse,re,json
from pathlib import Path
from urllib.parse import urlparse
from xml.sax.saxutils import escape
p=argparse.ArgumentParser();p.add_argument('origin',help='Your real HTTPS origin, with no path');p.add_argument('--launch',action='store_true',help='Enable indexing after owner review');a=p.parse_args()
u=urlparse(a.origin)
if u.scheme!='https' or not u.netloc or u.path not in ('','/') or u.query or u.fragment or u.username: p.error('Use a real HTTPS origin with no path, query, or credentials.')
origin=a.origin.rstrip('/');root=Path(__file__).resolve().parents[1]
urls=[]
for f in sorted(root.glob('*.html')):
 text=f.read_text();url=origin+('/' if f.name=='index.html' else '/'+f.name)
 text=re.sub(r'<link[^>]*rel="canonical"[^>]*>','',text);text=re.sub(r'<meta[^>]*property="og:url"[^>]*>','',text)
 text=text.replace('</head>',f'<link rel="canonical" href="{escape(url)}"><meta property="og:url" content="{escape(url)}"></head>')
 text=text.replace('<!-- DOMAIN_PENDING: run tools/configure_domain.py before launch; it inserts absolute canonical and og:url tags. -->','')
 if a.launch and f.name!='404.html':text=re.sub(r'<meta(?=[^>]*name="robots")[^>]*>','<meta name="robots" content="index, follow">',text)
 f.write_text(text)
 if f.name!='404.html':urls.append(url)
(root/'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+''.join('  <url><loc>'+escape(url)+'</loc></url>\n' for url in urls)+'</urlset>\n')
(root/'robots.txt').write_text('User-agent: *\n'+('Allow: /\n' if a.launch else 'Disallow: /\n')+'Sitemap: '+origin+'/sitemap.xml\n')
c=root/'js/config.js';c.write_text(re.sub(r"domain: [\"'][^\"']*[\"']",'domain: '+json.dumps(origin),c.read_text()))
print('Configured '+str(len(urls))+' sitemap URLs; indexing '+('enabled' if a.launch else 'disabled for review'))
