'use strict';
(function () {
  const header = document.querySelector('.site-header');
  const menu = document.querySelector('.menu-toggle');
  const nav = document.querySelector('#primary-nav');
  if (header && menu && nav) {
    header.classList.add('js-nav');
    function closeMenu() { menu.setAttribute('aria-expanded', 'false'); nav.classList.remove('is-open'); }
    menu.addEventListener('click', () => { const open = menu.getAttribute('aria-expanded') !== 'true'; menu.setAttribute('aria-expanded', String(open)); nav.classList.toggle('is-open', open); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && menu.getAttribute('aria-expanded') === 'true') { closeMenu(); menu.focus(); } });
    nav.addEventListener('click', e => { if (e.target.closest('a')) closeMenu(); });
    window.matchMedia('(min-width:901px)').addEventListener('change', closeMenu);
  }
  document.querySelectorAll('[data-currency]').forEach(button => button.addEventListener('click', () => {
    const currency = button.dataset.currency;
    document.querySelectorAll('[data-currency]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.currency === currency)));
    document.querySelectorAll('[data-usd]').forEach(price => {
      price.replaceChildren(document.createTextNode(currency === 'USD' ? '$' + price.dataset.usd : 'Custom quote'));
      const detail = document.createElement('small'); detail.textContent = currency === 'USD' ? 'starting / project' : 'Pakistan · PKR · rates pending approval'; price.append(detail);
    });
  }));
  document.querySelectorAll('[data-filter]').forEach(button => button.addEventListener('click', () => {
    const filter = button.dataset.filter; let count = 0;
    document.querySelectorAll('[data-filter]').forEach(b => b.setAttribute('aria-pressed', String(b === button)));
    document.querySelectorAll('.project-card[data-category]').forEach(card => { card.hidden = filter !== 'All' && card.dataset.category !== filter; if (!card.hidden) count++; });
    document.getElementById('filter-count').textContent = 'Showing ' + count + ' project' + (count === 1 ? '' : 's');
  }));
  const motion = window.matchMedia('(prefers-reduced-motion: reduce)');
  if ('IntersectionObserver' in window && !motion.matches) {
    const observer = new IntersectionObserver(entries => entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('reveal-in'); observer.unobserve(entry.target); } }), {threshold: 0.1});
    document.querySelectorAll('.section-heading, .project-card, .timeline article').forEach(el => observer.observe(el));
  }
  function whatsappURL(message) { return 'https://wa.me/' + window.SITE_CONFIG.whatsapp + '?text=' + encodeURIComponent(message); }
  function showMessage(message) {
    document.getElementById('message-preview').textContent = message;
    const link = document.getElementById('whatsapp-send'); link.href = whatsappURL(message);
    const summary = document.getElementById('request-summary'); summary.hidden = false; summary.focus();
  }
  function clearSummary() { const summary = document.getElementById('request-summary'); if (summary) { summary.hidden = true; document.getElementById('whatsapp-send').removeAttribute('href'); } }
  function validate(form, extraErrors = {}) {
    const errors = {...extraErrors};
    form.querySelectorAll('input,select,textarea').forEach(field => {
      if (!field.value.trim() && field.required) errors[field.name] = 'Please complete this field.';
      else if (field.value && !field.validity.valid) errors[field.name] = field.type === 'email' ? 'Enter a valid email address.' : field.type === 'url' ? 'Enter a full website URL, starting with https:// or http://.' : 'Please enter a valid value.';
      if (field.type === 'url' && field.value && !/^https?:\/\//i.test(field.value)) errors[field.name] = 'Use an http:// or https:// website URL.';
      const label = document.getElementById(field.id + '-error'); if (label) label.textContent = errors[field.name] || '';
      field.setAttribute('aria-invalid', String(!!errors[field.name]));
    });
    const errorBox = document.getElementById('form-errors');
    errorBox.textContent = Object.keys(errors).length ? 'Please check the highlighted fields. Your message has not been prepared or sent.' : '';
    if (Object.keys(errors).length) { clearSummary(); form.querySelector('[aria-invalid="true"]')?.focus(); return false; }
    return true;
  }
  window.SiteForms = {whatsappURL, showMessage, clearSummary, validate};
  const form = document.getElementById('inquiry-form');
  if (form) {
    const params = new URLSearchParams(location.search);
    if (params.get('review') === '1') form.elements.project.value = 'Website review';
    if (params.get('monthly') === '1') form.elements.engagement.value = 'Monthly support';
    const projectNames = {haider:'Haider Design and Contracting',wellnez:'Wellnez Beauty and Spa',urbankey:'UrbanKey Properties',olympia:'Olympia Gym Fitness Club',markethub:'MarketHub',urban:'Urban Properties',learnora:'Learnora Online Tutoring',velora:'Velora Digital',arshad:'Arshad Computer Lab',goride:'Go Ride Car Rentals'};
    if (projectNames[params.get('project')]) form.elements.details.value = 'I would like to discuss a website similar to ' + projectNames[params.get('project')] + '. ';
    form.addEventListener('input', clearSummary);
    form.addEventListener('change', clearSummary);
    form.addEventListener('submit', e => {
      e.preventDefault(); if (!validate(form)) return;
      const v = Object.fromEntries(new FormData(form));
      showMessage(['Hello Fatima, I would like to discuss my website.', '', 'Name: '+v.name.trim(), 'Email: '+v.email.trim(), 'Project type: '+v.project, 'Package: '+v.package, 'Work arrangement: '+v.engagement, 'Preferred next step: '+v.meeting, 'Current website: '+(v.website.trim() || 'Not provided'), '', 'Project details:', v.details.trim(), '', 'I understand any meeting or office visit needs your manual confirmation.'].join('\n'));
    });
  }
}());
