'use strict';
window.SITE_CONFIG = Object.freeze({
  brand: 'Dev Fatima Akram', name: 'Fatima Akram',
  email: 'devfatimaakram@gmail.com', whatsapp: '923083602029',
  timezone: 'Asia/Karachi', durationMinutes: 20,
  domain: '', // Set with tools/configure_domain.py after domain approval.
  schedulingProvider: null, // No calendar, email API, or booking integration is active.
  profiles: {linkedin: null, fiverr: null, upwork: null}
});
