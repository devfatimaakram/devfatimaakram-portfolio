'use strict';
(function (root) {
  function pakistanNow(now = new Date()) {
    const parts = new Intl.DateTimeFormat('en-CA', {timeZone:'Asia/Karachi', year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(now);
    const p = Object.fromEntries(parts.map(x => [x.type, x.value]));
    return {date:`${p.year}-${p.month}-${p.day}`,minutes:Number(p.hour)*60+Number(p.minute)};
  }
  function validDate(date) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return false;
    const parsed = new Date(date+'T12:00:00Z');
    return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0,10) === date;
  }
  function availableTimes(date, now = new Date()) {
    const today = pakistanNow(now);
    if (!validDate(date) || date < today.date || new Date(date+'T12:00:00Z').getUTCDay() === 0) return [];
    const slots=[];
    for(let minutes=600;minutes<=930;minutes+=30) {
      if(date===today.date && minutes<=today.minutes) continue;
      slots.push(String(Math.floor(minutes/60)).padStart(2,'0')+':'+String(minutes%60).padStart(2,'0'));
    }
    return slots;
  }
  function timeLabel(time) { const [h,m]=time.split(':').map(Number); return `${h%12||12}:${String(m).padStart(2,'0')} ${h>=12?'PM':'AM'}`; }
  function dateError(date, now = new Date()) {
    if(!validDate(date)) return 'Choose a valid date.';
    if(date < pakistanNow(now).date) return 'Choose today or a future date in Pakistan time.';
    if(new Date(date+'T12:00:00Z').getUTCDay() === 0) return 'Sundays are unavailable. Choose Monday through Saturday.';
    if(!availableTimes(date,now).length) return 'No suggested times remain on this date. Choose another day.';
    return '';
  }
  function message(v) {
    return ['Hello Fatima, I would like to request a 20-minute meeting.', '', 'Name: '+v.name.trim(), 'Email: '+v.email.trim(), 'Phone: '+(v.phone.trim()||'Not provided'), 'Project type: '+v.project, 'Package: '+v.package, 'Budget: '+(v.budget.trim()||'To discuss'), 'Requested date: '+v.date, 'Requested time: '+timeLabel(v.time)+' · Asia/Karachi (UTC+5)', 'Meeting type: '+v.meeting, '', 'Project details:',v.details.trim(),'', 'This is a request, not a confirmed booking. Please confirm availability manually. Office visits require approval before travel.'].join('\n');
  }
  root.BookingLogic = {pakistanNow,validDate,availableTimes,timeLabel,dateError,message};
  if(typeof module !== 'undefined' && module.exports) module.exports=root.BookingLogic;
  if(typeof document === 'undefined') return;
  const form=document.getElementById('booking-form'); if(!form) return;
  const date=form.elements.date,time=form.elements.time;
  const params=new URLSearchParams(location.search);const pkg=params.get('package');
  if(['Standard','Business','E-Commerce','Custom'].includes(pkg)) form.elements.package.value=pkg;
  function refreshTimes() {
    const previous=time.value;date.min=pakistanNow().date;
    time.replaceChildren(new Option('Select a suggested start time',''));
    const error=date.value?dateError(date.value):'';
    if(date.value) availableTimes(date.value).forEach(slot => time.add(new Option(timeLabel(slot),slot)));
    if([...time.options].some(o=>o.value===previous)) time.value=previous;
    time.disabled=!date.value||!!error;
    document.getElementById('date-error').textContent=error;date.setAttribute('aria-invalid',String(!!error));
  }
  refreshTimes();date.addEventListener('change',refreshTimes);
  form.addEventListener('input',root.SiteForms.clearSummary);form.addEventListener('change',root.SiteForms.clearSummary);
  // Refresh stale slots when returning to the tab; submission always rechecks the clock.
  document.addEventListener('visibilitychange',()=>{if(!document.hidden){refreshTimes();root.SiteForms.clearSummary();}});
  form.addEventListener('submit',e=>{
    e.preventDefault();const errors={};const de=dateError(date.value);if(de) errors.date=de;
    if(!availableTimes(date.value).includes(time.value)) errors.time='Choose an available suggested time for this date.';
    if(!root.SiteForms.validate(form,errors)) return;
    root.SiteForms.showMessage(message(Object.fromEntries(new FormData(form))));
  });
}(typeof window !== 'undefined'?window:globalThis));
