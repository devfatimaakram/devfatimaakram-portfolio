# Launch checklist

## Owner decisions before publishing

- [ ] Confirm the Urban Properties artwork. The supplied UrbanKey Luxury Homes image is not silently assigned to it. There are exactly 10 projects.
- [ ] Review all project descriptions and presentation-focus features; no verified live URLs or technical implementation details were supplied.
- [ ] Confirm permission to publish supplied portfolio artwork, embedded third-party marks/materials, portrait, and diploma certificate. Mockup testimonials/statistics are not endorsed as factual client results.
- [ ] Approve final copy, certificate display, logo sizing, and design. Logo and palette derive from supplied assets.
- [ ] Supply any earlier approved HTML/ZIP if its content must be compared; none was available for this build.
- [ ] Supply verified Fiverr, Upwork, and LinkedIn profile URLs or retain the honest pending states.
- [ ] Approve exact PKR rates or keep custom quotes. Review the $100/$200/$300 defined international scopes.
- [ ] Define project proposal/payment terms and monthly hours, limits, response targets, payment dates, cancellation, unused hours, and extra-work rules.
- [ ] Review and approve Privacy Policy and Terms & Conditions, effective dates, communications retention, host processing practices, and any jurisdiction-specific requirements with appropriate advice.
- [ ] Provide the real domain. Configure canonical URLs, OG URLs, sitemap, and indexing with the included tool only when ready to launch.

## Missing or mismatched assets

- No portrait/logo/certificate missing after the attachments arrived.
- Haider Design & Contracting artwork arrived and has been integrated.
- Urban Properties: image mapping remains unconfirmed; labeled placeholder retained.
- UrbanKey Luxury Homes: supplied image retained and displayed separately as unassigned artwork. It is not an eleventh project.
- All other supplied project artwork is mapped in `assets/images/ASSET-MANIFEST.md`.

## External services not connected

- [ ] GitHub repository and Vercel project: create/import yourself using README.
- [ ] Domain, DNS, HTTPS: configure and verify after deployment.
- [ ] WhatsApp/email: confirm the provided phone number and email; manually test delivery yourself.
- [ ] Calendar/scheduling: no live reservation or availability connection exists.
- [ ] Automatic emails/form backend: not installed; none are required for the WhatsApp workflow.
- [ ] Analytics: none installed. Update the policy if added.
- [ ] Marketplace/profile accounts: verified URLs pending.

## Manual browser and live deployment QA still required

The managed preview service was unavailable during this build, so rendered responsive and interactive browser QA could not be completed. Automated static checks and DOM/logic tests are reported separately in QA-REPORT.md; do not treat them as browser visual verification.

- [ ] Test 360, 390, 768, 1024, and 1440px widths; check no horizontal page overflow, image legibility, and footer spacing.
- [ ] Test mobile menu, Escape to close, keyboard focus, tab order, and skip link.
- [ ] Test every portfolio filter and project-brief link.
- [ ] Switch USD/PKR on Home, Pricing, Project Pricing, and Hire Me.
- [ ] Test empty/invalid contact form, email, website URL, review prefill, and WhatsApp preview with special characters.
- [ ] Test booking past dates, Sundays, same-day expired slots, date changes, midnight rollover, and an office-visit request. Confirm every message field and Pakistan time.
- [ ] On the actual phone/browser, open WhatsApp and send a test message yourself; confirm reception. No messages were sent during build testing.
- [ ] Test reduced motion and JavaScript disabled; page content/contact links should remain usable.
- [ ] Review contrast over artwork, text scaling to 200%, screen-reader labels/errors, and touch targets.
- [ ] Check all pages, image paths, real domain redirects, canonical tags, social previews, sitemap, robots, and custom 404 on Vercel.
- [ ] Check performance with browser DevTools/Lighthouse after deployment; no performance score has been claimed.
- [ ] Remove review-only notices only after the corresponding issue is resolved; preserve manual booking disclosures.
