# Dev Fatima Akram — portfolio website

A complete static website for final owner review. HTML5, CSS3, and vanilla JavaScript. No build command, framework, package installation, or backend is required. All 12 requested main pages plus `404.html` are included. No deployment has been made.

## Start here

1. Extract `dev-fatima-akram-website.zip`.
2. Open the extracted `dev-fatima-akram-website` folder.
3. Open `index.html` in a modern browser. Relative links, styles, images, and JavaScript work directly from the folder.
4. For an optional local web preview, run `python3 -m http.server 8000` from that folder, then visit `http://localhost:8000`.
5. Read `LAUNCH-CHECKLIST.md`, `QA-REPORT.md`, and `assets/images/ASSET-MANIFEST.md` before publishing.

## Files and editing

- Root HTML files contain complete content and shared header/footer markup. Content and navigation remain available without JavaScript.
- `css/style.css`: shared design, responsive breakpoints, focus states, and reduced-motion support. Palette tokens are at the top; forest and gold are based on the supplied logo and cream/green portfolio artwork.
- `js/config.js`: central contact and integration configuration for form messages. Contact links and public text are also present in HTML so they work without JavaScript; update both when details change.
- `js/main.js`: navigation, filters, USD/PKR display, contact validation, and prepared WhatsApp messages.
- `js/booking.js`: pure date/time helpers and the meeting-request form. All slot calculations use Asia/Karachi, regardless of the visitor’s timezone.
- `assets/images`: local optimized artwork, portrait, certificate, logo, and the asset inventory. Card images have smaller variants; full artwork can be opened from project briefs.
- `assets/favicon.png`: favicon derived from the supplied FA monogram.
- `tools/configure_domain.py`: optional one-time SEO configuration tool. Python is only needed for this maintenance utility, not to serve the site.
- `tools/test-booking.cjs`: repeatable Node tests for booking rules. Node is only needed to rerun the test, not for hosting.
- `vercel.json`: buildless static hosting configuration and basic response headers.

The header and footer are intentionally present in each HTML page for static accessibility and SEO. Shared styling and behavior live in CSS/JS; when changing navigation or contact details, apply the same markup change across all 13 HTML files. No runtime HTML injection or build step is needed. The 404 page sets its base to the deployed domain root so nested missing URLs still load its navigation and assets; preview that page through a local server or Vercel rather than opening it directly as a file.

## Content and asset status

All written content is based on the supplied detailed brief; no earlier website ZIP or HTML source was attached. The supplied brand logo, professional portrait, certificate, and clearly matched artwork have been integrated. The Haider artwork was supplied after the written brief, so it is displayed rather than replaced with a placeholder.

There are exactly 10 portfolio cards. Urban Properties remains a separate project with an honest placeholder. UrbanKey Luxury Homes artwork appears only in a clearly labeled “assignment pending” disclosure, not as an eleventh project. Confirm its mapping before launch. Artwork claims, embedded testimonials, and numbers are not represented as verified outcomes.

## Pricing

USD starting prices: Standard $100, Business $200, E-Commerce $300. Advanced projects and every monthly plan require a custom quote. No approved PKR rates were supplied; the Pakistan selector shows custom quotes and does not perform currency conversion. All package inclusions/exclusions follow the brief.

## Forms and meeting requests

Contact and booking forms validate input locally, display a readable preview, then offer a WhatsApp link to `923083602029`. Visitors must click the link and press Send themselves. Changing a field hides the old preview to prevent sending stale information.

Booking uses Monday–Saturday, 10:00 AM–3:30 PM start times at 30-minute intervals, a 20-minute duration, and Pakistan time (UTC+5). Past dates, Sundays, and slots at or before the current minute are rejected. The native date control is paired with clear error messages; Sundays are rejected before a request can be prepared. Time availability is checked again on submission and when returning to the tab.

There is no server-side database, calendar availability check, reserved appointment, confirmation email, form submission endpoint, analytics, or tracking cookie. The website does not store form entries. WhatsApp and email services process information when visitors choose to use them. Browser autofill and the eventual hosting provider have their own behavior.

## Upload to GitHub

1. Sign in to your GitHub account and create a new repository with your chosen name.
2. Upload the **contents** of the extracted website folder to the repository root: `index.html` should be at the top level, alongside `css`, `js`, and `assets`. Do not upload only the ZIP.
3. Commit the files. Keep the README and checklist in the repository for maintenance.
4. If you use Git locally instead, initialize a repository, commit the files, add the actual remote URL shown by GitHub, and push your main branch. No remote URL has been invented or preconfigured.

## Deploy through Vercel

1. Sign in to Vercel and choose Add New → Project.
2. Connect GitHub and import the repository you created.
3. Set Framework Preset to **Other**.
4. Set Root Directory to the folder containing `index.html` (repository root if uploaded as above).
5. Leave Build Command empty; no build is required. Use output directory `.`. The included `vercel.json` declares these settings.
6. Deploy, then open the returned URL and repeat the launch checks on mobile and desktop.
7. Test a nonexistent URL to confirm the custom `404.html` response works. Do not add an SPA catch-all rewrite; this is a multi-page static website.

The `.vercelignore` file excludes maintenance scripts, markdown reports, and unused original logo files from deployment; runtime assets remain included.

## Connect your real domain and enable indexing

No domain was supplied and none is invented. The review build has `noindex, nofollow`, `robots.txt` with `Disallow: /`, and an empty XML sitemap template. Canonical and Open Graph URL placeholders are comments, not broken fake URLs. Do not submit the review sitemap to search engines.

1. In the Vercel project’s domain settings, add your actual domain and follow the current DNS records Vercel provides. Do not guess DNS values.
2. Verify domain ownership/DNS and HTTPS certificate status in Vercel. Confirm the real HTTPS site loads.
3. After final content/legal approval, run `python3 tools/configure_domain.py https://YOUR_REAL_DOMAIN --launch`, replacing the argument with your real domain. This writes canonical and `og:url` tags, all 12 absolute sitemap URLs, updates the config domain, and enables indexing except on the 404 page. Without `--launch`, review indexing remains disabled.
4. Commit and push those changes. Verify the updated deployed HTML, `robots.txt`, and `sitemap.xml`.
5. Optionally add an approved social sharing image and an absolute `og:image` URL to each page. No fabricated social-preview image is configured.

If you do not use Python, update those same files manually. A domain change requires updating canonical URLs, OG URLs, config, robots sitemap location, and every sitemap URL.

## External accounts and future integrations

Not connected: GitHub repository, Vercel project, custom domain/DNS, live scheduling provider, calendar, transactional email, form backend, analytics, and verified Fiverr/Upwork/LinkedIn profile URLs. WhatsApp and mailto links are configured; account ownership, message delivery, and responses were not tested by sending messages.

For real scheduling later: create an account with the provider you select, connect an authorized calendar, configure availability in Asia/Karachi, set event duration and office-visit rules, and test conflicts/cancellations. Replace the request adapter only after successful integration. If a calendar API or transactional email needs secrets, use a backend/serverless function and environment variables—never put keys in these public JavaScript files. Confirm data retention and update the privacy policy. Keep manual-confirmation copy until real confirmation behavior exists.

Profile URLs: supply and verify the exact URLs before adding clickable links. The current Fiverr/Upwork cards clearly say pending. LinkedIn headline/banner wording is preserved, but no profile link is fabricated.

## Official documentation consulted

- Vercel static build configuration: https://vercel.com/docs/builds/configure-a-build
- Vercel project settings: https://vercel.com/docs/project-configuration/vercel-json
- GitHub existing code guide: https://docs.github.com/en/migrations/importing-source-code/using-the-command-line-to-import-source-code/adding-locally-hosted-code-to-github

Dashboard wording can change; use the official guidance above if settings move.
