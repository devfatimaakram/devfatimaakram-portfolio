# Supplied assets and mapping

All 15 attached files were visually inspected in a labeled contact sheet; Haider, the uncertain property artwork, the logo, and the certificate were also inspected at full size.

Integrated: supplied FA logo, portrait, diploma certificate, nine project artwork images with clear matches, and the additional UrbanKey Luxury Homes artwork in a clearly marked unassigned section. There are exactly 10 project cards; Urban Properties remains a placeholder.

| Local asset | Supplied source | Status |
|---|---|---|
| haider.webp | ChatGPT Image Oct 29, 2026, 10_56_32 AM-1.png | Integrated |
| wellnez.webp | ChatGPT Image Oct 29, 2026, 10_56_33 AM-2(1).png | Integrated |
| urbankey.webp | ChatGPT Image Oct 29, 2026, 10_56_34 AM-3(1).png | Integrated |
| urbankey-luxury-unassigned.webp | ChatGPT Image Oct 29, 2026, 10_56_36 AM-4(1).png | Unassigned; review panel only |
| olympia.webp | ChatGPT Image Oct 29, 2026, 10_56_37 AM-5(1).png | Integrated |
| markethub.webp | ChatGPT Image Oct 29, 2026, 10_56_38 AM-6(1).png | Integrated |
| learnora.webp | ChatGPT Image Oct 29, 2026, 10_56_39 AM-7(1).png | Integrated |
| velora.webp | ChatGPT Image Oct 29, 2026, 10_56_40 AM-8(1).png | Integrated |
| arshad.webp | ChatGPT Image Oct 29, 2026, 10_56_41 AM-9(1).png | Integrated |
| goride.webp | ChatGPT Image Oct 29, 2026, 10_56_42 AM-10(1).png | Integrated |
| portrait.webp | Professional Portrait in Green Hijab and Mask(1).png | Integrated |
| certificate.webp | Screenshot 2026-10-29 114725.png | Integrated |

The supplied Haider artwork arrived after the initial brief and clearly identifies Haider Design & Contracting. It replaces the initially requested placeholder. No logo, photograph, certificate, testimonial, or project art was invented.

Logo: transparent FA artwork used in the header; supplied cream-background variant retained locally. Transparent duplicate files contain the same visible brand design; no extra identity created. Favicon is cropped from the supplied FA monogram.

Urban Properties is separate from UrbanKey Properties. Confirm whether UrbanKey Luxury Homes artwork belongs to Urban Properties; until then the artwork remains unassigned. No business results or promotional claims inside any artwork are adopted as verified facts.

No original website ZIP or HTML files were supplied. This build uses the detailed written brief as its content source.

Images are optimized WebP with 560px card variants, descriptive alt text and intrinsic dimensions. Hero portrait loads eagerly; below-fold images are lazy-loaded. Logo originals are retained. CSS palette follows the supplied dark green logo and gold/cream artwork; exact tokens remain adjustable in css/style.css.
