# QA report — 29 October 2026

## Result

The static source and automated behavior checks passed. This is a complete downloadable review project, not a deployed or fully browser-verified production site. Visual responsive QA remains open because the managed preview daemon was unavailable (`sites-previewd mailbox is unavailable`); both preview start and status reported the same infrastructure error. No alternate browser environment was used to bypass it.

## Tests actually performed

### Static content, files, and structure

- Parsed all 13 HTML files: 12 main pages plus 404.
- Verified one H1 per page, English document language, viewport metadata, unique page titles and meta descriptions.
- Checked 462 local href/src references and all internal fragment destinations. No missing local targets were found.
- Checked 33 image appearances for descriptive alt text and intrinsic dimensions; validated every srcset target.
- Decoded/verified every delivered WebP/PNG asset, including the favicon. Empty image output encountered during initial conversion was repaired and the final files were rechecked.
- Checked each form input/select/textarea has a matching label and an existing accessible error-description target; checked for duplicate IDs.
- Confirmed exactly 10 project cards and distinct Urban Properties / UrbanKey Properties entries.
- Confirmed USD prices 100 / 200 / 300 across Home, Pricing, Project Pricing, and Hire Me.
- Confirmed the exact official tagline and signature appear on every page.
- Ran `node --check` on config.js, main.js, and booking.js.
- Parsed Vercel JSON and the review XML sitemap.
- Ran the domain configuration script on an isolated disposable copy with a reserved test domain. Confirmed all 12 absolute sitemap URLs, canonical and OG URL tags, enabled launch indexing, and continued noindex on 404. The actual deliverable remains in domain-pending review mode.

### Booking logic — 11 tests passed

Run again with `node tools/test-booking.cjs` (Node needed only for this test).

1. Pakistan time calculation independent of host timezone.
2. Past dates excluded.
3. Sundays excluded.
4. Malformed and impossible dates excluded.
5. Same-day expired start times excluded.
6. Future weekday has all 12 half-hour starts from 10:00 through 15:30.
7. Start time exactly equal to the current minute excluded.
8. No same-day slots after the last start time.
9. Pakistan midnight rollover.
10. Clear Sunday validation reason.
11. All meeting fields included, international phone URL correct, and special characters / Unicode / newlines survive URL encoding.

### DOM behavior — 9 tests passed

Run in a temporary jsdom harness (no jsdom or npm dependencies are part of the website). These are DOM tests, not a rendered-browser or assistive-technology audit.

1. Empty inquiry rejected; first invalid field receives focus.
2. Invalid email and non-HTTP website URL rejected.
3. Valid inquiry creates the expected encoded WhatsApp message; HTML-like input is rendered as text; edits clear stale previews.
4. Website review and monthly support links prefill the correct fields.
5. Portfolio filter count/visibility: 10 total and 3 Commerce cards, reset works.
6. USD/PKR selection on all four pricing pages; PKR shows custom quote and USD restores exact starting prices.
7. Menu expansion, Escape closing, and focus restoration.
8. Booking package prefill and Sunday rejection.
9. Valid future booking request with complete name/email/phone/project/package/budget/date/time/meeting/details message.

### Contrast and motion source checks

Calculated WCAG contrast ratios for solid token pairs:

| Pair | Ratio |
|---|---:|
| Body ink / cream | 12.62:1 |
| Muted text / cream | 5.52:1 |
| Button text / forest | 12.82:1 |
| Gold text / forest | 7.96:1 |
| Dark text / gold button | 9.44:1 |
| Error text / cream | 6.37:1 |
| Footer secondary / deep green | 10.36:1 |

All seven tested pairs exceed 4.5:1. This does not verify every rendered combination or text embedded inside supplied images. CSS includes explicit focus styling, responsive breakpoints, a reduced-motion override, and a horizontally scrollable comparison table. Reveal animation never hides content by default. These were inspected in source, not visually in a browser.

## Not performed / remaining limits

- Rendered tests at mobile, tablet, laptop, or desktop widths; screenshots; horizontal-overflow measurements.
- Real-device keyboard/touch/screen-reader audit, zoom audit, or computed visual contrast over portrait/artwork.
- Actual WhatsApp sends, email delivery, calendar access, or account ownership checks.
- GitHub upload, Vercel deployment, live HTTP checks, DNS, HTTPS, redirects, or production 404 verification.
- Lighthouse/performance scoring or live SEO crawling. No score, ranking, or business outcome is claimed.
- Legal approval or independent verification of qualifications and project implementation. Background comes from the user; images are supplied presentation material.

See LAUNCH-CHECKLIST.md for remaining decisions, asset mapping, external services, and manual checks.
